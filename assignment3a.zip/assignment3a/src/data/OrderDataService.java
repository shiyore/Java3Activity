package data;


import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;
import javax.ejb.Local;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;

import beans.Order;

/**
 * Session Bean implementation class OrderDataService
 */
@Stateless
@Local(DataAccessInterface.class)
@LocalBean
public class OrderDataService implements DataAccessInterface <Order>{

    /**
     * Default constructor. 
     */
    public OrderDataService() {
        // TODO Auto-generated constructor stub
    }

	@Override
	public List findAll() {
		List<Order> orders = new ArrayList<Order>();
		
		String url = "jdbc:postgresql://localhost:5432/postgres";
		String username = "postgres";
		String password = "root";
		Connection conn = null;
		String query = "SELECT * FROM testapp.Orders";
		
		try {
			//connect to the database
			conn = DriverManager.getConnection(url,username,password);
			
			
			//execute the query
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			
			while(rs.next()) {
				orders.add(new Order(rs.getString("order_no"),
						rs.getString("product_name"),
						rs.getFloat("price"), 
						rs.getInt("quantity")));
			}
			//cleanup
			rs.close();
			conn.close();
			System.out.println("Successfully connected");
		}
		catch(SQLException e) {
			e.printStackTrace();
			System.out.println("Failed to query.");
		}
		finally {
			if (conn != null)
				try {
					conn.close();
				}
				catch(SQLException e){
					e.printStackTrace();
				}
		}
		System.out.println(orders);
		return orders;
	}

	@Override
	public Order findById(int id) {
		// TODO Auto-generated method stub
		return null;
	}

	public boolean create(Order order) {
		// TODO Auto-generated method stub
		String url = "jdbc:postgresql://localhost:5432/postgres";
		String username = "postgres";
		String password = "root";
		Connection conn = null;
		String query = "SELECT * FROM testapp.Orders(order_no, product_name, quantity) VALUES('888888888', 'I pitty the FOOL',999999999999, 100)";
		
		try {
			conn = DriverManager.getConnection(url, username, password);
			Statement stat = conn.createStatement();
			stat.executeUpdate(query);
		}
		catch(SQLException e) {
			e.printStackTrace();
		}
		finally {
			if(conn != null) {
				try {
					conn.close();
				}
				catch(SQLException e) {
					e.printStackTrace();
				}
			}
		}
		return true;
	}

	public boolean update(Order order) {
		// TODO Auto-generated method stub
		return false;
	}

	public boolean delete(Order order) {
		// TODO Auto-generated method stub
		return false;
	}

    

}

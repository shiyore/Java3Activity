package data;
import java.util.List;

import beans.Order;

public interface DataAccessInterface <T>{
	public List<T> findAll();
	public T findById(int id);
	public boolean create(Order order);
	public boolean update(Order order);
	public boolean delete(Order order);
}

package controllers;

import beans.Order;
import beans.User;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.List;

import javax.ejb.EJB;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
//import javax.swing.Timer;

import business.MyTimerService;
import business.OrdersBusinessInterface;

@ManagedBean
@ViewScoped
public class FormController {
	//User user;
	@Inject
	OrdersBusinessInterface service;
	//@EJB
	//MyTimerService timer;
	
	public String onSendOrder() {
		System.out.println("onSendOrder()");
		service.sendOrder(new Order());
		return "OrderResponse.xhtml";
	}
	
	public String onSubmit(User user) {
		//Forward to Test Response View along with the User Managed Bean
		service.test();
		
		//call getAllOrders()
		//getAllOrders();	
		
		/**String url = "jdbc:postgresql://localhost:5432/postgres";
		String username = "postgres";
		String password = "root";
		
		try {
			Connection conn = DriverManager.getConnection(url,username,password);
			conn.close();
			System.out.println("Successfully connected");
		}
		catch(SQLException e) {
			//e.printStackTrace();
			System.out.println("It failed.");
		}**/
		
		//timer.setTimer(10000);
		//findAll();
		getAllOrders();
		insertOrder();
		getAllOrders();
		FacesContext.getCurrentInstance().getExternalContext().getRequestMap().put("user", user);
		return "TestResponse.xhtml";
	}
	
	//create a private Function getAllOrders to return void
	/*public List<Order> findAll(){
		List<Order> orders = new ArrayList<Order>();
		
		String url = "jdbc:postgresql://localhost:5432/postgres/testapp";
		String username = "postgres";
		String password = "root";
		Connection conn = null;
		
		
		try {
			//connect to the database
			conn = DriverManager.getConnection(url,username,password);
			String query = "SELECT * FROM testapp.Orders";
			
			//execute the query
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			
			while(rs.next()) {
				orders.add(new Order(rs.getString("order_no"),
						rs.getString("product_name"),
						rs.getFloat("price"), 
						rs.getInt("quantity")));
			}
			//cleanup
			rs.close();
			conn.close();
			System.out.println("Successfully connected");
		}
		catch(SQLException e) {
			e.printStackTrace();
			System.out.println("Failed to query.");
		}
		finally {
			if (conn != null)
				try {
					conn.close();
				}
				catch(SQLException e){
					e.printStackTrace();
				}
		}
		System.out.println(orders);
		return orders;
	}
	
	private void insertOrder() {
		String url = "jdbc:postgresql://localhost:5432/postgres/testapp";
		String username = "postgres";
		String password = "root";
		Connection conn = null;
		String sql = "";
		
		try {
			conn = DriverManager.getConnection();
		}
		catch(SQLException e) {
			
		}
	}*/
	
	public OrdersBusinessInterface getService() {
		return service;
	}
	
	private void insertOrder() {
		String url = "jdbc:postgresql://localhost:5432/postgres";
		String username = "postgres";
		String password = "root";
		Connection conn = null;
		String query = "INSERT INTO  testapp.ORDERS(ORDER_NO, PRODUCT_NAME, PRICE, QUANTITY) " + "VALUES('001122334455', 'This was inserted new', 25.00, 100)";
		
		try {
			//connect to the database
			conn = DriverManager.getConnection(url,username,password);
			
			
			//execute the query
			Statement stmt = conn.createStatement();
			stmt.executeUpdate(query);
			
			
			//cleanup
			//rs.close();
			conn.close();
			System.out.println("Successfully connected");
		}
		catch(SQLException e) {
			e.printStackTrace();
			System.out.println("Failed to query.");
		}
		finally {
			if (conn != null)
				try {
					conn.close();
				}
				catch(SQLException e){
					e.printStackTrace();
				}
		}
	}
	
	private void getAllOrders() {
		String url = "jdbc:postgresql://localhost:5432/postgres";
		String username = "postgres";
		String password = "root";
		Connection conn = null;
		String query = "SELECT * FROM testapp.Orders";
		
		try {
			//connect to the database
			conn = DriverManager.getConnection(url,username,password);
			
			
			//execute the query
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			
			while(rs.next()) {
				System.out.println("id: " + rs.getInt("id") + " product name: " + rs.getString("product_name") + " Price: " + rs.getFloat("price"));
			}
			//cleanup
			rs.close();
			conn.close();
			System.out.println("Successfully connected");
		}
		catch(SQLException e) {
			e.printStackTrace();
			System.out.println("Failed to query.");
		}
		finally {
			if (conn != null)
				try {
					conn.close();
				}
				catch(SQLException e){
					e.printStackTrace();
				}
		}
	}
	
}

package business;


import java.util.ArrayList;
import java.util.List;

import javax.annotation.Resource;
import javax.ejb.EJB;
import javax.ejb.Local;
import javax.ejb.LocalBean;
import javax.ejb.Stateless;
import javax.enterprise.inject.Alternative;
import javax.jms.Connection;
import javax.jms.ConnectionFactory;
import javax.jms.JMSException;
import javax.jms.MessageProducer;
import javax.jms.ObjectMessage;
import javax.jms.Queue;
import javax.jms.Session;
import javax.jms.TextMessage;

import beans.Order;
import beans.Orders;
import data.DataAccessInterface;
import data.OrderDataService;

/**
 * Session Bean implementation class OrdersBusinessService
 */
@Stateless
@Local(OrdersBusinessInterface.class)
@LocalBean
@Alternative
public class OrdersBusinessService implements OrdersBusinessInterface {

    @EJB
    DataAccessInterface<Order> service;
    
    @Resource(mappedName="java:/ConnectionFactory")
    private ConnectionFactory connectionFactory;
    
    @Resource(mappedName="java:/jms/queue/Order")
    private Queue queue;
    
	List<Order> orders = new ArrayList<Order>();
    public OrdersBusinessService() {
        // TODO Auto-generated constructor stub
    	/*orders.add(new Order("00000002" , "Gold Monkey" , (float)1.00 , 1));
		orders.add(new Order("00000014" , "Dirty Handsoap" , (float)13.00 , 197));
		orders.add(new Order("00005023" , "A clove of garlic" , (float)900.23 , 1));
		orders.add(new Order("00000432" , "A Shaq\'s fist full of misc. candy" , (float)47.95 , 3));
		orders.add(new Order("00000300" , "Snicker Bar" , (float)27.40 , 58));
		orders.add(new Order("00006723" , "A 13mm mouse" , (float)0.57 , 3));
		orders.add(new Order("00302049" , "A small lump of hair" , (float)2.00 , 800));
		orders.add(new Order("00003051" , "A cup of spit" , (float)56.29 , 6));
		orders.add(new Order("00000230" , "A mysterious finger" , (float)98.20 , 4));*/
    }

	/**
     * @see OrdersBusinessInterface#test()
     */
    public void test() {
        // TODO Auto-generated method stub
    	System.out.println("Hello from the other side");
    }


	public List<Order> getOrders() {
		// TODO Auto-generated method stub
		return service.findAll();
	}


	public void setOrders(List<Orders> orders) {
		// TODO Auto-generated method stub
		
	}
	public void sendOrder(Order order) {
		try {
			Connection connection = connectionFactory.createConnection();
			Session session = connection.createSession(false, Session.AUTO_ACKNOWLEDGE);
			
			MessageProducer messageProducer = session.createProducer(queue);
			
			TextMessage message1 = session.createTextMessage();
			message1.setText("This is test message");
			messageProducer.send(message1);
			
			ObjectMessage message2 = session.createObjectMessage();
			message2.setObject(order);
			messageProducer.send(message2);
			
			connection.close();
			
		}catch(JMSException e) {
			e.printStackTrace();
		}
	}

}
